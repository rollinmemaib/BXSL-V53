from Heart.Packets.PiranhaMessage import PiranhaMessage
import datetime
import time
import brawlstats
import random

class PlayerProfileMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        
        self.writeVLong(fields["PlayerHighID"], fields["PlayerLowID"])
        self.writeDataReference(0)
        self.writeVInt(63)
        for i in range(63):
            self.writeDataReference(16, i)
            self.writeDataReference(0)
            self.writeVInt(500) # trophies
            self.writeVInt(1250) # highestTrophies
            self.writeVInt(11) #power level
        
        self.writeVInt(17)

        self.writeVInt(1) 
        self.writeVInt(1) # 3v3 victories

        self.writeVInt(2)
        self.writeVInt(0) # total exp

        self.writeVInt(3)
        self.writeVInt(player.Trophies) # current trophies

        self.writeVInt(4)
        self.writeVInt(player.HighestTrophies) # highest trophies

        self.writeVInt(5) 
        self.writeVInt(0) # unlocked brawler?

        self.writeVInt(8)
        self.writeVInt(2) # solo victories

        self.writeVInt(11) 
        self.writeVInt(3) # duo victories

        self.writeVInt(9) 
        self.writeVInt(0) # highest level robo rumble

        self.writeVInt(12) 
        self.writeVInt(0) # highest level boss fight

        self.writeVInt(13)
        self.writeVInt(0) # highest power league points

        self.writeVInt(14)
        self.writeVInt(0) # some power league stuff

        self.writeVInt(15)
        self.writeVInt(0) # most challenge win

        self.writeVInt(16) #highest level city rampage
        self.writeVInt(0)

        self.writeVInt(18) #highest solo power league rank
        self.writeVInt(19)

        self.writeVInt(17) #highest team power league rank
        self.writeVInt(19)

        self.writeVInt(19) # highest Club league rank
        self.writeVInt(0)

        self.writeVInt(20) # number fame
        self.writeVInt(5000)

        self.writeString("risporce")  #PlayerInfo
        self.writeVInt(0)
        self.writeVInt(28000001)
        self.writeVInt(43000001)
        self.writeVInt(46000001)

        self.writeBoolean(False)

        self.writeBoolean(False)
        
        

        self.writeDataReference(25, 1) #alliance role

    def decode(self):
        pass
        # fields = {}
        # fields["PlayerCount"] = self.readVInt()
        # fields["Text"] = self.readString()
        # fields["Unk1"] = self.readVInt()
        # super().decode(fields)
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24113

    def getMessageVersion(self):
        return self.messageVersion